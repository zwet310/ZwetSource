# TriOS Live — сборка дистрибутива с нуля

Минимальный live-дистрибутив на базе Debian (trixie) с графикой Wayland
(композитор labwc), автологином и автозапуском `trios-launcher.py`
при старте сессии. В систему сразу включены DOSBox, Wine и Waydroid.

## Что внутри

```
auto/config                        — конфигурация live-build
auto/build, auto/clean             — сборка и очистка
config/package-lists/...           — список пакетов системы
config/hooks/0100-waydroid.chroot  — установка Waydroid на этапе сборки
config/includes.chroot/...         — файлы, попадающие в образ:
    /usr/local/bin/trios-launcher.py   сам лаунчер
    /usr/local/bin/install.sh          доустановка окружения
    /usr/local/bin/trios-session       сессия Wayland (labwc)
    /usr/share/wayland-sessions/       запись сессии для lightdm
    /etc/skel/.config/labwc/autostart  АВТОЗАПУСК лаунчера при входе
    /etc/lightdm/lightdm.conf          автологин пользователя trios
build.sh                           — сборка одной командой
```

## Как собрать

Нужен Debian/Ubuntu (или контейнер с Debian), ~20 ГБ места, интернет.

```bash
sudo bash build.sh
```

Результат — `trios-live-amd64.iso`. Проверить:

```bash
qemu-system-x86_64 -m 4G -enable-kvm -cdrom trios-live-amd64.iso -vga virtio
```

## Как это работает

1. ISO грузится в live-режим, создаётся пользователь `trios`.
2. LightDM делает автологин и запускает Wayland-сессию labwc.
3. labwc исполняет `/etc/skel/.config/labwc/autostart` — строчка
   `python3 /usr/local/bin/trios-launcher.py &` поднимает лаунчер.
4. Лаунчер запускает DOSBox / Wine / Waydroid. Tk работает через XWayland.

## Замечания

- Waydroid полноценно работает на железе с GPU и в сессии Wayland;
  в QEMU графика Android ограничена.
- Если на этапе сборки нет сети, Waydroid пропустится — тогда запустите
  внутри готовой системы «Установить недостающее» в лаунчере.
- Для постоянной установки на диск добавьте `debian-installer` или
  используйте `lb config --debian-installer live`.
