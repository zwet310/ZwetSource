#!/usr/bin/env bash
# Сборка TriOS Live ISO. Запуск на Debian/Ubuntu (или в контейнере с Debian):
#   sudo bash build.sh
set -e

echo "== Установка инструментов сборки =="
sudo apt-get update
sudo apt-get install -y live-build debootstrap squashfs-tools xorriso dosfstools

echo "== Очистка предыдущей сборки =="
sudo ./auto/clean || true

echo "== Конфигурация =="
./auto/config

echo "== Сборка ISO (15–60 минут, нужен интернет) =="
sudo ./auto/build

ISO=$(ls -1t *.iso 2>/dev/null | head -n1 || true)
if [ -n "$ISO" ]; then
  echo
  echo "== Готово: $ISO =="
  echo "Проверка в QEMU:"
  echo "  qemu-system-x86_64 -m 4G -enable-kvm -cdrom $ISO -vga virtio"
else
  echo "Сборка не завершилась — смотрите build.log"
  exit 1
fi
